package com.example.kozintek;

import io.github.gleidson28.GNAvatarView;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class HSProfileController {

    @FXML
    private GNAvatarView imageHS;
    @FXML
    private Text firstnameHS;
    @FXML
    private Text age;
    @FXML
    private Text city;
    @FXML
    private Text pricing;
    @FXML
    private Text rank;
    @FXML
    private Text reviews;
    @FXML
    private ImageView stars;
    @FXML
    private Rectangle monday;
    @FXML
    private Rectangle tuesday;
    @FXML
    private Rectangle wednesday;
    @FXML
    private Rectangle thursday;
    @FXML
    private Rectangle friday;
    @FXML
    private Rectangle saturday;
    @FXML
    private Rectangle sunday;
    @FXML
    private Rectangle cleaning;
    @FXML
    private Rectangle cooking;
    @FXML
    private Rectangle baby;

    @FXML
    private Text Bio;

    private Integer cardId;

    @FXML
    private ScrollPane ReviewsPane;

    private static HSProfileController Instance;
    public HSProfileController(){
        Instance = this;
    }
    public static HSProfileController getInstance(){
        return Instance;
    }


    public void setInfos(String first,String a,String c,String p,String  ra,String rev) {
        firstnameHS.setText(first);
        age.setText(a);
        city.setText(c);
        pricing.setText(p.toString());
        rank.setText(ra.toString());
        reviews.setText(rev.toString() +" Reviews");
    }

    public void setImage(Image imageBlob) {
        imageHS.setImage(imageBlob);
    }
    public void setSkills( Rectangle[] WorkDays ) {
        cleaning.setStyle(WorkDays[0].getStyle());
        cooking.setStyle(WorkDays[1].getStyle());
        baby.setStyle(WorkDays[2].getStyle());
    }
    public void setDays( Rectangle[] WorkDays ) {
        monday.setStyle(WorkDays[0].getStyle());
        tuesday.setStyle(WorkDays[1].getStyle());
        wednesday.setStyle(WorkDays[2].getStyle());
        thursday.setStyle(WorkDays[3].getStyle());
        friday.setStyle(WorkDays[4].getStyle());
        saturday.setStyle(WorkDays[5].getStyle());
        sunday.setStyle(WorkDays[6].getStyle());
    }
    public void setStars( Float nbr ) {

        ArrayList<Image> starsList = new ArrayList<>();

        for (int i = 0; i < 11; i++) {
            starsList.add(new Image("file:src/main/resources/assets/Icons/starsh/stars" + i + ".png"));
        }

        if (nbr < 1) {
            stars.setImage(starsList.get(1));
        } else if (nbr > 1 && nbr < 2) {
            stars.setImage(starsList.get(2));
        } else if (nbr > 2 && nbr < 3) {
            stars.setImage(starsList.get(4));
        } else if (nbr > 3 && nbr < 4) {
            stars.setImage(starsList.get(7));
        } else if (nbr > 4 && nbr < 5) {
            stars.setImage(starsList.get(8));
        } else if (nbr == 5) {
            stars.setImage(starsList.get(10));
        } else if (nbr == 4) {
            stars.setImage(starsList.get(9));
        } else if (nbr == 3) {
            stars.setImage(starsList.get(6));
        } else if (nbr == 2) {
            stars.setImage(starsList.get(5));
        } else if (nbr == 1) {
            stars.setImage(starsList.get(3));
        }
    }
    public void setCardId( Integer id ){
        cardId = id;
    }
    public void setBio() {
        Bio.setText(CardDisplayController.getInstance().HousekeeperObservableList.get(cardId).bio);
    }

    public void showReviews( Integer cardId ) throws Exception {
        ReviewDisplay ctrl = loadinReviewsPane("ReviewsDisplay.fxml");

        ctrl.importReviews(cardId);
        ctrl.ShowReviews();
    }

    public ReviewDisplay loadinReviewsPane( String fxmlFile ) throws IOException  {
        ReviewsPane.setStyle("-fx-background-color:transparent;");
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(fxmlFile));
        Pane newScene = loader.load();
        ReviewsPane.setContent(newScene);
        ReviewsPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        ReviewsPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        ReviewsPane.setFitToWidth(true);

        return loader.getController();
    }

    public void loadPane( Pane newScene ) throws Exception {
        ReviewsPane.setStyle("-fx-background-color:transparent;");
        ReviewsPane.setContent(newScene);
        ReviewsPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        ReviewsPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        ReviewsPane.setFitToWidth(true);
    }

    public void HomeButton (ActionEvent event) throws IOException {
        HomeController.getInstance().loadMid("CardsDisplay.fxml");
        HomeController.getInstance().showit(false);
        HomeController.getInstance().setMidHV(HomeController.getInstance().getvValueSave(),0);
    }

}
