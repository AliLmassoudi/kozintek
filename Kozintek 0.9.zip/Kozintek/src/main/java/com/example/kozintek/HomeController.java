package com.example.kozintek;

import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import java.io.IOException;
import java.sql.*;

public class HomeController {

    @FXML
    private AnchorPane HeaderAnchorPane;

    @FXML
    private ScrollPane Mid;
    @FXML
    private Button HomeButton;
    @FXML
    private Button ProfileButton;
    @FXML
    private Button SettingsButton;
    @FXML
    private Rectangle NavRect;
    @FXML
    private AnchorPane BottomAnchor;

    double vValueSave ;
    TranslateTransition translate = new TranslateTransition();

    // Instance Stuff for passing the controller hh
    private static HomeController Instance;
    public HomeController(){
        Instance = this;
    }
    public static HomeController getInstance(){
        return Instance;
    }

    public void loadHeader(String firstname, Blob image) throws IOException, SQLException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Header.fxml"));
        HeaderAnchorPane.getChildren().add(loader.load());

        HeaderController hdrctrl = loader.getController();;
        hdrctrl.setUsername(firstname);
        hdrctrl.setImage(image);
    }

    public void loadMid( String fxmlFile ) throws IOException  {
        Mid.setStyle("-fx-background-color:transparent;");
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(fxmlFile));
        Pane newScene = loader.load();
        Mid.setContent(newScene);
        Mid.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        Mid.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        Mid.setFitToWidth(true);
    }
    public void loadPaneinMid( Pane newScene ) throws Exception {
        Mid.setStyle("-fx-background-color:transparent;");
        Mid.setContent(newScene);
        Mid.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        Mid.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        Mid.setFitToWidth(true);
    }

    public void HomeButton() throws IOException {
        translate.setDuration(Duration.millis(500));
        translate.setNode(NavRect);
        translate.setToX(100);
        translate.play();
        loadMid("CardsDisplay.fxml");
    }
    public void ProfileButton() throws IOException {
        translate.setDuration(Duration.millis(500));
        translate.setNode(NavRect);
        translate.setToX(69);
        translate.play();
        //loadMid("CardsDisplay.fxml");
    }
    public void SettingsButton() throws IOException {
        translate.setDuration(Duration.millis(500));
        translate.setNode(NavRect);
        translate.setToX(255);
        translate.play();
        //loadMid("CardsDisplay.fxml");
    }

    public void showit(boolean bruh){
        BottomAnchor.setVisible(bruh);
    }
    public void setMidHV(double v , double h){
        Mid.setVvalue(v);
        Mid.setHvalue(h);
    }
    public double getMidV(){
        return Mid.getVvalue();
    }
    public void setvValueSave(double bruh){
        vValueSave = bruh;
    }
    public double getvValueSave(){
       return vValueSave;
    }
}

