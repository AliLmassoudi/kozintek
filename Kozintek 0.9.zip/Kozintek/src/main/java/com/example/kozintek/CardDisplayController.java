package com.example.kozintek;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;

import java.net.URL;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CardDisplayController implements Initializable {

    @FXML
    private Pane cards;

    private static CardDisplayController Instance;
    public CardDisplayController(){
        Instance = this;
    }
    public static CardDisplayController getInstance(){
        return Instance;
    }

    ObservableList<HousekeeperModel> HousekeeperObservableList = FXCollections.observableArrayList();

    public void importHousekeepers() throws Exception {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String HousekeeperVieweQuery = "SELECT id,firstname,lastname,age,ranking,reviews,monday,tuesday,wednesday,thursday,friday,saturday,sunday,cleaning,cooking,baby,email,city,score,pricing,image,bio FROM Housekeepers";

        try {

            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(HousekeeperVieweQuery);

            while (queryOutput.next()) {

                Integer id = queryOutput.getInt("id");
                Integer age = queryOutput.getInt("age");
                Integer ranking = queryOutput.getInt("ranking");
                Integer reviews = queryOutput.getInt("reviews");

                String firstname = queryOutput.getString("firstname");
                String lastname = queryOutput.getString("lastname");
                String monday = queryOutput.getString("monday");
                String tuesday = queryOutput.getString("tuesday");
                String wednesday = queryOutput.getString("wednesday");
                String thursday = queryOutput.getString("thursday");
                String friday = queryOutput.getString("friday");
                String saturday = queryOutput.getString("saturday");
                String sunday = queryOutput.getString("sunday");
                String cleaning = queryOutput.getString("cleaning");
                String cooking = queryOutput.getString("cooking");
                String baby = queryOutput.getString("baby");
                String email = queryOutput.getString("email");
                String city = queryOutput.getString("city");
                String bio = queryOutput.getString("bio");

                Float score = queryOutput.getFloat("score");
                Float pricing = queryOutput.getFloat("pricing");

                Blob image = queryOutput.getBlob("image");

                HousekeeperObservableList.add( new HousekeeperModel(id,age,ranking,reviews,firstname,monday,tuesday,wednesday,thursday,friday,saturday,sunday,cleaning,cooking,baby,lastname,email,city,bio,score,pricing,image));
            }
        } catch (Exception e){
            Logger.getLogger(HousekeeperModel.class.getName()).log(Level.SEVERE, null , e);
            e.printStackTrace();
        }


    }
    public void writeCard ( CardController ctrl , int i ) throws Exception {
        ctrl.setInfos(HousekeeperObservableList.get(i).firstname,HousekeeperObservableList.get(i).lastname,HousekeeperObservableList.get(i).age,HousekeeperObservableList.get(i).score,HousekeeperObservableList.get(i).city,HousekeeperObservableList.get(i).pricing,HousekeeperObservableList.get(i).ranking,HousekeeperObservableList.get(i).reviews);
        ctrl.setImage(HousekeeperObservableList.get(i).image);
        ctrl.setStars(HousekeeperObservableList.get(i).score);
        String WorkDays[] = { HousekeeperObservableList.get(i).monday,HousekeeperObservableList.get(i).tuesday,HousekeeperObservableList.get(i).wednesday,HousekeeperObservableList.get(i).thursday,HousekeeperObservableList.get(i).friday,HousekeeperObservableList.get(i).saturday,HousekeeperObservableList.get(i).sunday};
        ctrl.setDays(WorkDays);
        String Skills[] = { HousekeeperObservableList.get(i).cleaning,HousekeeperObservableList.get(i).cooking,HousekeeperObservableList.get(i).baby};
        ctrl.setSkills(Skills);
    }
    public void ShowCards() throws Exception {

        int posX = 23;
        int posY = 15;

        ArrayList<AnchorPane> anchorPanes = new ArrayList<>();
        ArrayList<CardController> cardControllers = new ArrayList<>();

        FXMLLoader loader = new FXMLLoader();
        CardController cardController = new CardController();

        cards.setPrefHeight(Region.USE_COMPUTED_SIZE);

        for ( int i = 0 ; i < HousekeeperObservableList.size() ; i++) {
            anchorPanes.add(new AnchorPane ());
            anchorPanes.get(i).setPrefWidth(330);anchorPanes.get(i).setPrefHeight(270);
            anchorPanes.get(i).setLayoutX(posX);anchorPanes.get(i).setLayoutY(posY);

            loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Card.fxml"));
            anchorPanes.get(i).getChildren().add(loader.load());
            cards.getChildren().add(anchorPanes.get(i));
            cardController = loader.getController();

            writeCard(cardController,i);
            sendCardId(cardController,i);

            cardControllers.add(cardController);

            posY = posY + 290 ;
        }
    }
    public void sendCardId(CardController ctrl , int i){
        ctrl.setCardId(HousekeeperObservableList.get(i).id);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {

            importHousekeepers();
            ShowCards();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public ObservableList HousekeeperObservableList(){
        return HousekeeperObservableList;
    }
}
