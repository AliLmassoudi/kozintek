package com.example.kozintek;

import io.github.gleidson28.GNAvatarView;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.sql.rowset.serial.SerialBlob;

import java.io.*;
import java.net.URL;
import java.nio.ByteBuffer;
import java.sql.*;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class SignUpHKController implements Initializable {

    @FXML
    private GNAvatarView UploadedImage;
    @FXML
    private ScrollPane SC;
    @FXML
    private TextField Firstname;
    @FXML
    private TextField Lastname;
    @FXML
    private TextField Email;
    @FXML
    private TextField Age;
    @FXML
    private TextField City;
    @FXML
    private TextField Pricing;
    @FXML
    private TextArea Bio;

    @FXML
    private RadioButton Baby;
    @FXML
    private RadioButton Cooking;
    @FXML
    private RadioButton Cleaning;

    @FXML
    private RadioButton Monday;
    @FXML
    private RadioButton Tuesday;
    @FXML
    private RadioButton Wednesday;
    @FXML
    private RadioButton Thursday;
    @FXML
    private RadioButton Friday;
    @FXML
    private RadioButton Saturday;
    @FXML
    private RadioButton Sunday;
    @FXML
    private Button addImage;

    private Stage stage ;
    private Scene scene ;
    private Parent root ;

    File imageFile ;
    InputStream inputStream ;

    public void NextButton(ActionEvent event) throws IOException, SQLException {


        if ( checkFields() == true && Bio.getText().isBlank() == false ){

            String firstname = Firstname.getText();
            String lastname = Lastname.getText();
            String email = Email.getText();
            String city = City.getText();
            String bio = Bio.getText();

            Integer age = Integer.valueOf(Age.getText());
            Float pricing = Float.valueOf(Pricing.getText());

            Integer score = 5;
            Integer ranking = 300;
            Integer reviews = 123;

            String monday = getDayValue(Monday);
            String tuesday = getDayValue(Tuesday);
            String wednesday = getDayValue(Wednesday);
            String thursday = getDayValue(Thursday);
            String friday = getDayValue(Friday);
            String saturday = getDayValue(Saturday);
            String sunday = getDayValue(Sunday);

            String baby = getDayValue(Baby);
            String cooking = getDayValue(Cooking);
            String cleaning = getDayValue(Cleaning);

            try {
                DatabaseConnection connectNow = new DatabaseConnection();
                Connection connectDB = connectNow.getConnection();

                PreparedStatement statement = connectDB.prepareStatement("INSERT INTO `Kozintek`.`Housekeepers` (`firstname`, `lastname`, `email`, `age`, `city`, `score`, `pricing`, `ranking`, `image`, `reviews`, `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`, `cleaning`, `cooking`, `baby`, `bio`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                statement.setString(1, firstname);
                statement.setString(2, lastname);
                statement.setString(3, email);
                statement.setInt(4, age);
                statement.setString(5, city);
                statement.setFloat(6, score);
                statement.setFloat(7, pricing);
                statement.setInt(8, ranking);
                statement.setBinaryStream(9, inputStream);
                statement.setInt(10, reviews);

                statement.setString(11, monday);
                statement.setString(12, tuesday);
                statement.setString(13, wednesday);
                statement.setString(14, thursday);
                statement.setString(15, friday);
                statement.setString(16, saturday);
                statement.setString(17, sunday);

                statement.setString(18, cleaning);
                statement.setString(19, cooking);
                statement.setString(20, baby);

                statement.setString(21, bio);

                statement.executeUpdate();
                System.out.println("l3AZZZZZ");

                FXMLLoader loader = new FXMLLoader(getClass().getResource("Done.fxml"));
                root = loader.load();

                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene =  new Scene(root);
                stage.setScene(scene);
                stage.show();


            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else if (checkFields() == false) {
            if ( Bio.getText().isBlank()==true ){
                Bio.setStyle("-fx-border-color: #ff5a5a; -fx-border-radius: 6; -fx-background-radius: 8 ; -fx-background-color:white; -fx-border-width: 2");
            }
            if ( inputStream == null){
                addImage.setStyle("-fx-border-color: #ff5a5a; -fx-border-radius: 6 ; -fx-background-radius: 8 ; -fx-background-color:white; -fx-border-width: 2");
            }
            System.out.println("khoya 3mr kolchi");
        }
    }

    public void PickImage() throws FileNotFoundException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            Image image = new Image(selectedFile.toURI().toString());
            imageFile = selectedFile;
            inputStream = new FileInputStream(selectedFile);
            UploadedImage.setImage(image);
        }
    }

    public Boolean checkFields() {

        TextField[] fields = {Firstname,Lastname,Email,City,Age,Pricing};
        for ( TextField field : fields ) {
            if(field.getText().isBlank() == true){
                field.setStyle("-fx-border-color: #ff5a5a; -fx-border-radius: 6; -fx-background-radius: 8; -fx-background-color:white; -fx-border-width: 2");
            }else if(field.getText().isBlank() == false){
                System.out.println("nn");
            }
        }
        if ( Firstname.getText().isBlank() == false && Lastname.getText().isBlank() == false && Email.getText().isBlank() == false && City.getText().isBlank() == false && Age.getText().isBlank() == false && Pricing.getText().isBlank() == false ){
            return true;
        }else {
            return false;
        }
    }

    public String getDayValue( RadioButton btn ){
        if ( btn.isSelected() == true ){
            return "1";
        }else {
            return "0";
        }
    }

    public void Previous(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SignUpChoose.fxml"));
        root = loader.load();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene =  new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        SC.setBackground(
                new Background(new BackgroundFill(Color.TRANSPARENT, null, null))
        );

        System.out.println(Monday.getText());
    }
}
