package com.example.kozintek;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainController {

    @FXML
    private Button LoginButton ;
    @FXML
    private Button SigninButton;
    @FXML
    private Button ResetPasswordButton;
    @FXML
    private TextField EmailTextField;
    @FXML
    private TextField PasswordTextField;
    @FXML
    private Label EmailErrorMsg;
    @FXML
    private Label PasswordErrorMsg;
    @FXML
    private Label BlankEmailMsg;
    @FXML
    private Label BlankPasswordMsg;
    @FXML
    private Label BonjourLabel;

    private Stage stage ;
    private Scene scene ;
    private Parent root ;

    ObservableList<UserModel> UserObservableList = FXCollections.observableArrayList();

    public void setLoginButtonOnAction(ActionEvent e) {

        if ( EmailTextField.getText().isBlank() == true ) {
            BlankEmailMsg.setText("Please enter your Email");
            EmailTextField.setStyle("-fx-border-color: #FF8914; -fx-border-radius: 6; -fx-background-color:white; -fx-font-family : \"Poppins\" ;-fx-font-size : 15px ; -fx-border-width: 2");
        }else{
            BlankEmailMsg.setText("");
            EmailTextField.setStyle("-fx-background-color:white; -fx-font-family : \"Poppins\" ;-fx-font-size : 15px ; -fx-border-width: 2");
        }if ( PasswordTextField.getText().isBlank() == true ) {
            BlankPasswordMsg.setText("Please enter your Password");
            PasswordTextField.setStyle("-fx-border-color: #FF8914; -fx-border-radius: 6; -fx-background-color:white; -fx-font-family : \"Poppins\" ;-fx-font-size : 15px ; -fx-border-width: 2");
        }else{
            BlankPasswordMsg.setText("");
            PasswordTextField.setStyle("-fx-background-color:white; -fx-font-family : \"Poppins\" ;-fx-font-size : 15px ; -fx-border-width: 2");
        }if ( EmailTextField.getText() == "bruh" && PasswordTextField.getText() == "bruh" ){
            BlankPasswordMsg.setText("IXILO");
        }

        if ( EmailTextField.getText().isBlank() == false && PasswordTextField.getText().isBlank() == false ) {
            validateLogin(e);
        }
    }

    public void validateLogin(ActionEvent event) {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String LoginVerifyQuery = "SELECT count(1) FROM UserAccounts WHERE Email = '" + EmailTextField.getText() + "' AND Password = '" + PasswordTextField.getText() + "'";

        try {
            Statement statement = connectDB.createStatement();
            ResultSet queryResult = statement.executeQuery(LoginVerifyQuery);

            while (queryResult.next()) {
                if (queryResult.getInt(1) == 1 ){

                    FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
                    root = loader.load();

                    // load user
                    loadUser();
                    String firstname = UserObservableList.get(0).Firstname;
                    Blob image = UserObservableList.get(0).Image;

                    HomeController homeCtrl = loader.getController();
                    homeCtrl.loadHeader(firstname,image);
                    homeCtrl.loadMid("CardsDisplay.fxml");

                    stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                    scene =  new Scene(root);
                    stage.setScene(scene);
                    stage.show();

                }else {
                    BlankEmailMsg.setText("Ser a3mo ser");
                    BlankEmailMsg.setText("Invalid Login");
                    EmailTextField.setStyle("-fx-border-color: #ff5a5a; -fx-border-radius: 6; -fx-background-color:white; -fx-font-family : \"Poppins\" ;-fx-font-size : 15px ; -fx-border-width: 2");
                    PasswordTextField.setStyle("-fx-border-color: #ff5a5a; -fx-border-radius: 6; -fx-background-color:white; -fx-font-family : \"Poppins\" ;-fx-font-size : 15px ; -fx-border-width: 2");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void loadUser() {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String LoadUser = "SELECT idUser,Firstname,Lastname,Email,Username,Password,Image FROM UserAccounts WHERE Email = '"+EmailTextField.getText()+"'";

        try {
            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(LoadUser);

            while (queryOutput.next()) {
                Integer idUser = queryOutput.getInt("idUser");

                String firstname = queryOutput.getString("Firstname");
                String lastname = queryOutput.getString("Lastname");
                String email = queryOutput.getString("Email");
                String username = queryOutput.getString("Username");
                String password = queryOutput.getString("Password");

                Blob image = queryOutput.getBlob("Image");

                UserObservableList.add( new UserModel(idUser,firstname,lastname,email,username,password,image));
            }
        }catch (Exception e){
            Logger.getLogger(HousekeeperModel.class.getName()).log(Level.SEVERE, null , e);
            e.printStackTrace();
        }
    }

}
