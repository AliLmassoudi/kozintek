package com.example.kozintek;

public class ReviewModel {

    Integer id,HousekeeperID,UserID;
    String Comment;
    Float Stars;

    public ReviewModel(Integer id, Integer userID, Integer housekeeperID, String comment, Float stars) {
        this.id = id;
        HousekeeperID = housekeeperID;
        UserID = userID;
        Comment = comment;
        Stars = stars;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getHousekeeperID() {
        return HousekeeperID;
    }

    public void setHousekeeperID(Integer housekeeperID) {
        HousekeeperID = housekeeperID;
    }

    public Integer getUserID() {
        return UserID;
    }

    public void setUserID(Integer userID) {
        UserID = userID;
    }

    public String getComment() {
        return Comment;
    }

    public void setComment(String comment) {
        Comment = comment;
    }

    public Float getStars() {
        return Stars;
    }

    public void setStars(Float stars) {
        Stars = stars;
    }
}
