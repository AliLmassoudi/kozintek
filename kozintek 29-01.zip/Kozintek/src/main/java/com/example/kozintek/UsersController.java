package com.example.kozintek;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import java.net.URL;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UsersController implements Initializable {

    private static UsersController Instance;
    public UsersController(){
        Instance = this;
    }
    public static UsersController getInstance(){
        return Instance;
    }

    ObservableList<UserModel> UsersObservableList = FXCollections.observableArrayList();

    public void importUsers() throws Exception {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String LoadUser = "SELECT idUser,Firstname,Lastname,Email,Username,Password,Image FROM UserAccounts ";

        try {
            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(LoadUser);

            while (queryOutput.next()) {
                Integer idUser = queryOutput.getInt("idUser");

                String firstname = queryOutput.getString("Firstname");
                String lastname = queryOutput.getString("Lastname");
                String email = queryOutput.getString("Email");
                String username = queryOutput.getString("Username");
                String password = queryOutput.getString("Password");

                Blob image = queryOutput.getBlob("Image");

                UsersObservableList.add( new UserModel(idUser,firstname,lastname,email,username,password,image));
            }
        }catch (Exception e){
            Logger.getLogger(HousekeeperModel.class.getName()).log(Level.SEVERE, null , e);
            e.printStackTrace();
        }
    }

    public UserModel getUser( Integer id ){
        return UsersObservableList.get(id-1);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            importUsers();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
