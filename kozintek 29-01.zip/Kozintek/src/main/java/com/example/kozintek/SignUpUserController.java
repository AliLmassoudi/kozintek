package com.example.kozintek;

import io.github.gleidson28.GNAvatarView;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SignUpUserController {

    @FXML
    private GNAvatarView UploadedImage;

    @FXML
    private TextField Firstname;
    @FXML
    private TextField Lastname;
    @FXML
    private TextField Email;
    @FXML
    private TextField Password;
    @FXML
    private TextField ConfirmPassword;
    @FXML
    private TextField Username;

    @FXML
    private Button addImage;

    private Stage stage ;
    private Scene scene ;
    private Parent root ;

    File imageFile ;
    InputStream inputStream ;

    public void PickImage() throws FileNotFoundException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            Image image = new Image(selectedFile.toURI().toString());
            imageFile = selectedFile;
            inputStream = new FileInputStream(selectedFile);
            UploadedImage.setImage(image);
        }
    }

    public void Previous(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SignUpChoose.fxml"));
        root = loader.load();

        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene =  new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    public void NextButton(ActionEvent event) throws IOException, SQLException {


        if ( checkFields() == true ){

            String firstname = Firstname.getText();
            String lastname = Lastname.getText();
            String email = Email.getText();
            String username = Username.getText();

            String password = Password.getText();
            String confpass = ConfirmPassword.getText();

            try {
                DatabaseConnection connectNow = new DatabaseConnection();
                Connection connectDB = connectNow.getConnection();

                PreparedStatement statement = connectDB.prepareStatement("INSERT INTO `Kozintek`.`UserAccounts` (`Firstname`, `Lastname`, `Email`, `Username`, `Password`, `Image`) VALUES (?, ?, ?, ?, ?, ?);");
                statement.setString(1, firstname);
                statement.setString(2, lastname);
                statement.setString(3, email);
                statement.setString(4, username);
                statement.setString(5, password);
                statement.setBinaryStream(6, inputStream);

                statement.executeUpdate();
                System.out.println("l3AZZZZZ");



                FXMLLoader loader = new FXMLLoader(getClass().getResource("Done.fxml"));
                root = loader.load();

                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene =  new Scene(root);
                stage.setScene(scene);
                stage.show();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else if (checkFields() == false) {
            if ( inputStream == null){
                addImage.setStyle("-fx-border-color: #ff5a5a; -fx-border-radius: 6 ; -fx-background-radius: 8 ; -fx-background-color:white; -fx-border-width: 2");
            }
            System.out.println("khoya 3mr kolchi");
        }
    }

    public Boolean checkFields() {

        TextField[] fields = {Firstname,Lastname,Email,Password,ConfirmPassword,Username};
        for ( TextField field : fields ) {
            if(field.getText().isBlank() == true){
                field.setStyle("-fx-border-color: #ff5a5a; -fx-border-radius: 6; -fx-background-radius: 8; -fx-background-color:white; -fx-border-width: 2");
            }else if(field.getText().isBlank() == false){
                System.out.println("nn");
            }
        }
        if ( Firstname.getText().isBlank() == false && Lastname.getText().isBlank() == false && Email.getText().isBlank() == false && Password.getText().isBlank() == false && ConfirmPassword.getText().isBlank() == false && Username.getText().isBlank() == false ){
            return true;
        }else {
            return false;
        }
    }

}
