package com.example.kozintek;

import io.github.gleidson28.GNAvatarView;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.text.Text;

import java.io.ByteArrayInputStream;
import java.net.URL;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class HeaderController{

    @FXML
    private Text username;
    @FXML
    private GNAvatarView userimage;

    public void setUsername(String bruh){
        username.setText(bruh);
    }
    public void setImage(Blob bruh) throws SQLException {
        byte[] imageData = bruh.getBytes(1, (int) bruh.length());
        Image imageresult = new Image(new ByteArrayInputStream(imageData));
        userimage.setImage(imageresult);
    }

}
