package com.example.kozintek;

import io.github.gleidson28.GNAvatarView;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.text.Text;

import java.io.ByteArrayInputStream;
import java.sql.Blob;
import java.sql.SQLException;

public class ReviewController {

    @FXML
    private GNAvatarView UserImage;
    @FXML
    private Text UserFullName;
    @FXML
    private Text Date;
    @FXML
    private Text Comment;

    public void setReview(Blob imageBlob , String fullname , String date , String cmnt) throws SQLException {

        byte[] imageData = imageBlob.getBytes(1, (int) imageBlob.length());
        Image imageresult = new Image(new ByteArrayInputStream(imageData));
        UserImage.setImage(imageresult);

        UserFullName.setText(fullname);
        Date.setText(date);
        Comment.setText(cmnt);
    }
}
