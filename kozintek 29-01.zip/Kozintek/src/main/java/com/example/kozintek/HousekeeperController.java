package com.example.kozintek;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;

import java.net.URL;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HousekeeperController implements Initializable {

    private static HousekeeperController Instance;
    public HousekeeperController(){
        Instance = this;
    }
    public static HousekeeperController getInstance(){
        return Instance;
    }

    ObservableList<HousekeeperModel> HousekeeperObservableList = FXCollections.observableArrayList();

    public void importHousekeepers() throws Exception {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String HousekeeperVieweQuery = "SELECT id,firstname,lastname,age,ranking,reviews,monday,tuesday,wednesday,thursday,friday,saturday,sunday,cleaning,cooking,baby,email,city,score,pricing,image,bio FROM Housekeepers";

        try {

            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(HousekeeperVieweQuery);

            while (queryOutput.next()) {

                Integer id = queryOutput.getInt("id");
                Integer age = queryOutput.getInt("age");
                Integer ranking = queryOutput.getInt("ranking");
                Integer reviews = queryOutput.getInt("reviews");

                String firstname = queryOutput.getString("firstname");
                String lastname = queryOutput.getString("lastname");
                String monday = queryOutput.getString("monday");
                String tuesday = queryOutput.getString("tuesday");
                String wednesday = queryOutput.getString("wednesday");
                String thursday = queryOutput.getString("thursday");
                String friday = queryOutput.getString("friday");
                String saturday = queryOutput.getString("saturday");
                String sunday = queryOutput.getString("sunday");
                String cleaning = queryOutput.getString("cleaning");
                String cooking = queryOutput.getString("cooking");
                String baby = queryOutput.getString("baby");
                String email = queryOutput.getString("email");
                String city = queryOutput.getString("city");
                String bio = queryOutput.getString("bio");

                Float score = queryOutput.getFloat("score");
                Float pricing = queryOutput.getFloat("pricing");

                Blob image = queryOutput.getBlob("image");

                HousekeeperObservableList.add( new HousekeeperModel(id,age,ranking,reviews,firstname,monday,tuesday,wednesday,thursday,friday,saturday,sunday,cleaning,cooking,baby,lastname,email,city,bio,score,pricing,image));
            }
        } catch (Exception e){
            Logger.getLogger(HousekeeperModel.class.getName()).log(Level.SEVERE, null , e);
            e.printStackTrace();
        }


    }

    public HousekeeperModel getHousekkeper( Integer id ){
        return HousekeeperObservableList.get(id-1);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            importHousekeepers();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
