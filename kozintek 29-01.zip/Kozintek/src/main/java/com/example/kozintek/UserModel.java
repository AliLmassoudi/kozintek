package com.example.kozintek;

import java.sql.Blob;

public class UserModel {

    Integer idUser;
    String Firstname,Lastname,Email,Username,Password;
    Blob Image;

    public UserModel(Integer idUser, String firstname, String lastname, String email, String username, String password, Blob image) {
        this.idUser = idUser;
        Firstname = firstname;
        Lastname = lastname;
        Email = email;
        Username = username;
        Password = password;
        Image = image;
    }

    public Blob getImage() {
        return Image;
    }

    public void setImage(Blob image) {
        Image = image;
    }

    public Integer getIdUser() {
        return idUser;
    }

    public void setIdUser(Integer idUser) {
        this.idUser = idUser;
    }

    public String getFirstname() {
        return Firstname;
    }

    public void setFirstname(String firstname) {
        Firstname = firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String lastname) {
        Lastname = lastname;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }


}
