package com.example.kozintek;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ReviewDisplay{

    private static ReviewDisplay Instance;
    public ReviewDisplay(){
        Instance = this;
    }
    public static ReviewDisplay getInstance(){
        return Instance;
    }

    @FXML
    private Pane Reviews;

    ObservableList<ReviewModel> ReviewsObservableList = FXCollections.observableArrayList();

    public void importReviews(Integer housekeeperID) throws Exception {
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String ReviewVieweQuery = "SELECT id,UserID,HousekeeperID,Comment,Stars FROM Reviews WHERE HousekeeperID = '"+housekeeperID+"'";

        try {

            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(ReviewVieweQuery);

            while (queryOutput.next()) {

                Integer id = queryOutput.getInt("id");
                Integer UserID = queryOutput.getInt("UserID");
                Integer HousekeeperID = queryOutput.getInt("HousekeeperID");

                String Comment = queryOutput.getString("Comment");

                Float Stars = queryOutput.getFloat("Stars");

                ReviewsObservableList.add( new ReviewModel(id,UserID,HousekeeperID,Comment,Stars));
            }
        } catch (Exception e){
            Logger.getLogger(HousekeeperModel.class.getName()).log(Level.SEVERE, null , e);
            e.printStackTrace();
        }
    }
    ArrayList<ReviewModel> result;


    public void writeReview(ReviewController ctrl , int i) throws Exception {
        UsersController usrctrl = new UsersController();
        usrctrl.importUsers();

        Blob image = usrctrl.getUser(ReviewsObservableList.get(i).UserID).Image;
        String FirstLast = UsersController.getInstance().getUser(ReviewsObservableList.get(i).UserID).Firstname + UsersController.getInstance().getUser(ReviewsObservableList.get(i).UserID).Lastname;
        String cmnt = ReviewsObservableList.get(i).Comment;

        ctrl.setReview(  image ,  FirstLast, "54-54-45" , cmnt);
    }

    public void ShowReviews() throws Exception {
        int posX = 23;
        int posY = 810;

        ArrayList<AnchorPane> anchorPanes = new ArrayList<>();

        FXMLLoader loader ;
        ReviewController reviewController ;

        System.out.println("Staaaart drawing Reviews");
        System.out.println("nbr of reviews : " + ReviewsObservableList.size());

        if ( ReviewsObservableList.size() == 0 ){
            System.out.println("bruuuh no reviews");
        }else {
            for ( int i = 0 ; i < ReviewsObservableList.size() ; i++) {

                System.out.println("Staaaart drawing Reviews 22222");

                anchorPanes.add(new AnchorPane ());
                anchorPanes.get(i).setPrefWidth(290);anchorPanes.get(i).setPrefHeight(183);
                anchorPanes.get(i).setLayoutX(posX);anchorPanes.get(i).setLayoutY(posY);

                loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("Review.fxml"));
                anchorPanes.get(i).getChildren().add(loader.load());
                Reviews.getChildren().add(anchorPanes.get(i));
                reviewController = loader.getController();

                writeReview(reviewController,i);

                UsersController usrctrl = new UsersController();
                usrctrl.importUsers();
                System.out.println( ReviewsObservableList.get(i).Comment + usrctrl.getUser(ReviewsObservableList.get(i).UserID).Firstname );

                posX = posX + 310;
            }
            HSProfileController.getInstance().loadPane(Reviews);
        }
    }
}
